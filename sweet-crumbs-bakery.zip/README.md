# 🧁 Sweet Crumbs Bakery

A beautiful, responsive bakery website featuring artisan cakes, pastries, and custom cake ordering.

![Bakery Website](https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80)

## ✨ Features

- **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Interactive Menu** - Filterable menu with categories (Cakes, Pastries, Cookies, Bread)
- **Shopping Cart** - Add items to cart with quantity management
- **Custom Cake Ordering** - Section for special custom cake requests
- **Contact Form** - Fully functional contact form with validation
- **Smooth Animations** - Beautiful hover effects and scroll animations
- **Modern UI** - Glass morphism effects, gradient text, and modern typography

## 🚀 Deployment

### Deploy to Vercel (Recommended)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/sweet-crumbs-bakery)

Or manually:

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/sweet-crumbs-bakery.git
   git push -u origin main
   ```

2. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Framework Preset: Select **"Other"** (static site)
   - Click "Deploy"

3. **Done!** Your site will be live in seconds with a `.vercel.app` domain.

### Deploy to Netlify

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/yourusername/sweet-crumbs-bakery)

### Deploy to GitHub Pages

1. Go to repository Settings → Pages
2. Source: Deploy from a branch
3. Branch: Select `main` / `(root)`
4. Click Save

## 🛠️ Technologies Used

- **HTML5** - Semantic markup
- **Tailwind CSS** - Utility-first CSS framework (via CDN)
- **Font Awesome** - Icons
- **Google Fonts** - Playfair Display & Lato fonts
- **Vanilla JavaScript** - Interactivity and cart functionality

## 📁 Project Structure

```
sweet-crumbs-bakery/
├── index.html          # Main HTML file
├── vercel.json         # Vercel deployment configuration
└── README.md           # This file
```

## 🎨 Customization

### Changing Colors
Edit the Tailwind config in the `<script>` tag within `index.html`:

```javascript
colors: {
    cream: '#FFF8E7',      // Background color
    chocolate: '#5D4037',  // Primary text
    rose: '#E8B4B8',       // Accent color
    gold: '#D4AF37',       // Secondary accent
}
```

### Adding Menu Items
Edit the `menuItems` array in the JavaScript section:

```javascript
const menuItems = [
    { 
        id: 13, 
        name: "Your New Item", 
        category: "cakes", 
        price: 50, 
        image: "https://your-image-url.jpg", 
        description: "Description here" 
    },
    // ... existing items
];
```

### Updating Images
Replace Unsplash URLs with your own images:
1. Upload images to your hosting service or Unsplash
2. Replace the `src` attributes in the HTML

## 📱 Pages/Sections

1. **Home** - Hero section with call-to-action
2. **Our Story** - About the bakery with stats
3. **Menu** - Filterable product grid with add-to-cart
4. **Custom Cakes** - Custom order information
5. **Testimonials** - Customer reviews
6. **Contact** - Contact form and location info

## 🔧 Local Development

Since this is a static HTML site, no build process is required:

```bash
# Simply open in browser
open index.html

# Or use a local server
npx serve .
# or
python -m http.server 8000
```

## 📝 License

MIT License - feel free to use this for your own bakery or business!

## 🙏 Credits

- Images from [Unsplash](https://unsplash.com)
- Icons from [Font Awesome](https://fontawesome.com)
- Fonts from [Google Fonts](https://fonts.google.com)

---

Made with ❤️ and flour
